'use client';

import React from 'react';
import ResponsiveGrid from './ResponsiveGrid';

export default function ProjectGrid() {
  return <ResponsiveGrid />;
}