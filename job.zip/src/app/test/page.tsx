export default function TestPage() {
  return (
    <div>
      <h1>Test Page</h1>
      <p>This is a simple test page without GSAP</p>
    </div>
  );
}