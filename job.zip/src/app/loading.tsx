import React from 'react';
import LoadingScreen from '@/components/loading/LoadingScreen';

export default function GlobalLoading() {
  return <LoadingScreen />;
}